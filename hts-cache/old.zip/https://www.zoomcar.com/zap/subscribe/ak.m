<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport"
    content="minimum-scale=1.0, width=device-width, height=device-height, maximum-scale=1, user-scalable=no">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="mobile-web-app-capable" content="yes">
  <meta
    content="Share your car & Earn | Amigo by Zoomcar"
    name="title">
  <meta
    content="Amigo by Zoomcar is a community car pooling program for private car owners to earn rewards
    and reduce ownership cost by sharing their cars on the Zoomcar platform while they are not in use.
    Amigo lets you earn money on an otherwise depreciating asset and do your bit for the environment by
    reducing carbon footprint."
    name="description">
  <link href="//cdn.jsdelivr.net/npm/@mdi/font@5.9.55/css/materialdesignicons.min.css" rel="stylesheet">
  
  <link href="//assets.zoomcar.com/assets/favicon-94c70086866938b66cbd6706cfb6e048.png" rel="shortcut icon"
    type="image/png">
  
  <title>Share your car & Earn | Amigo by Zoomcar</title>

  <link rel="preconnect" href="https://api.zoomcar.com" />
  <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans:400,500,600&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons&display=swap" rel="stylesheet">
  
  <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
  
    <link rel="preconnect" href="https://cdn.segment.com" />
    <link rel="preconnect" href="https://api.segment.io" />
  
  <link
    rel="manifest"
    href="/zap/subscribe/manifests/zoom.json"
  >
  <link rel="prefetch" as="video" type="video/mp4" href="https://www.zoomcar.com/zap/subscribe/build/92cbb4bf3d1d70a92233a45ed2010e9b.mp4" >
  <link rel="prefetch" as="video" type="video/mp4" href="https://www.zoomcar.com/zap/subscribe/build/0091465f6bdcb1e29b2fd3b39866039a.mp4" >
  <script src="https://cdn.polyfill.io/v2/polyfill.js?features=default,fetch" async></script>

  <!-- Google Tag Manager -->
  <script async>
    let standalone = window.navigator.standalone,
      userAgent = window.navigator.userAgent.toLowerCase(),
      safari = /safari/.test(userAgent),
      ios = /iphone|ipod|ipad/.test(userAgent),
      iosWebView;
    if (ios && (!standalone && !safari)) {
      iosWebView = true;
    }
    if (!iosWebView) {
      (function (w, d, s, l, i) {
        w[l] = w[l] || []; w[l].push({
          'gtm.start':
            new Date().getTime(), event: 'gtm.js'
        }); var f = d.getElementsByTagName(s)[0],
          j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
      })(window, document, 'script', 'dataLayer', 'GTM-N52Q36S');
      var _vwo_code = (function () {
        var account_id = 218859,
          settings_tolerance = 2000,
          library_tolerance = 2500,
          use_existing_jquery = false,
          /* DO NOT EDIT BELOW THIS LINE */
          f = false, d = document;
        return {
          use_existing_jquery: function () { return use_existing_jquery; },
          library_tolerance: function () { return library_tolerance; },
          finish: function () { if (!f) { f = true; var a = d.getElementById('_vis_opt_path_hides'); if (a) a.parentNode.removeChild(a); } },
          finished: function () { return f; },
          load: function (a) {
            var b = d.createElement('script');
            b.src = a; b.type = 'text/javascript'; b.innerText;
            b.onerror = function () { _vwo_code.finish(); }; d.getElementsByTagName('head')[0].appendChild(b);
          },
          init: function () {
            settings_timer = setTimeout('_vwo_code.finish()', settings_tolerance);
            var a = d.createElement('style'),
              b = 'body{opacity:0 !important;filter:alpha(opacity=0) !important;background:none !important;}',
              h = d.getElementsByTagName('head')[0];
            a.setAttribute('id', '_vis_opt_path_hides');
            a.setAttribute('type', 'text/css');
            if (a.styleSheet) a.styleSheet.cssText = b;
            else a.appendChild(d.createTextNode(b));
            h.appendChild(a);
            this.load('//dev.visualwebsiteoptimizer.com/j.php?a=' + account_id + '&u=' + encodeURIComponent(d.URL) + '&r=' + Math.random());
            return settings_timer;
          }
        };
      }());
      _vwo_settings_timer = _vwo_code.init();
    }
  </script>
  
<link rel="preload" as="script" href="https://www.zoomcar.com/zap/subscribe/build/app-166a37cdf7d2b3365bc8.bundle.js">
<link rel="preload" as="style" href="https://www.zoomcar.com/zap/subscribe/build/app-166a37cdf7d2b3365bc8.bundle.css">
<link rel="preload" as="script" href="https://www.zoomcar.com/zap/subscribe/build/vendor-166a37cdf7d2b3365bc8.bundle.js">
<link href="https://www.zoomcar.com/zap/subscribe/build/app-166a37cdf7d2b3365bc8.bundle.css" rel="stylesheet">
                              <script>!function(e){var n="https://s.go-mpulse.net/boomerang/";if("False"=="True")e.BOOMR_config=e.BOOMR_config||{},e.BOOMR_config.PageParams=e.BOOMR_config.PageParams||{},e.BOOMR_config.PageParams.pci=!0,n="https://s2.go-mpulse.net/boomerang/";if(window.BOOMR_API_key="PZ6TM-XV3V8-YENE4-H4ZS5-ZB376",function(){function e(){if(!o){var e=document.createElement("script");e.id="boomr-scr-as",e.src=window.BOOMR.url,e.async=!0,i.parentNode.appendChild(e),o=!0}}function t(e){o=!0;var n,t,a,r,d=document,O=window;if(window.BOOMR.snippetMethod=e?"if":"i",t=function(e,n){var t=d.createElement("script");t.id=n||"boomr-if-as",t.src=window.BOOMR.url,BOOMR_lstart=(new Date).getTime(),e=e||d.body,e.appendChild(t)},!window.addEventListener&&window.attachEvent&&navigator.userAgent.match(/MSIE [67]\./))return window.BOOMR.snippetMethod="s",void t(i.parentNode,"boomr-async");a=document.createElement("IFRAME"),a.src="about:blank",a.title="",a.role="presentation",a.loading="eager",r=(a.frameElement||a).style,r.width=0,r.height=0,r.border=0,r.display="none",i.parentNode.appendChild(a);try{O=a.contentWindow,d=O.document.open()}catch(_){n=document.domain,a.src="javascript:var d=document.open();d.domain='"+n+"';void(0);",O=a.contentWindow,d=O.document.open()}if(n)d._boomrl=function(){this.domain=n,t()},d.write("<bo"+"dy onload='document._boomrl();'>");else if(O._boomrl=function(){t()},O.addEventListener)O.addEventListener("load",O._boomrl,!1);else if(O.attachEvent)O.attachEvent("onload",O._boomrl);d.close()}function a(e){window.BOOMR_onload=e&&e.timeStamp||(new Date).getTime()}if(!window.BOOMR||!window.BOOMR.version&&!window.BOOMR.snippetExecuted){window.BOOMR=window.BOOMR||{},window.BOOMR.snippetStart=(new Date).getTime(),window.BOOMR.snippetExecuted=!0,window.BOOMR.snippetVersion=12,window.BOOMR.url=n+"PZ6TM-XV3V8-YENE4-H4ZS5-ZB376";var i=document.currentScript||document.getElementsByTagName("script")[0],o=!1,r=document.createElement("link");if(r.relList&&"function"==typeof r.relList.supports&&r.relList.supports("preload")&&"as"in r)window.BOOMR.snippetMethod="p",r.href=window.BOOMR.url,r.rel="preload",r.as="script",r.addEventListener("load",e),r.addEventListener("error",function(){t(!0)}),setTimeout(function(){if(!o)t(!0)},3e3),BOOMR_lstart=(new Date).getTime(),i.parentNode.appendChild(r);else t(!1);if(window.addEventListener)window.addEventListener("load",a,!1);else if(window.attachEvent)window.attachEvent("onload",a)}}(),"".length>0)if(e&&"performance"in e&&e.performance&&"function"==typeof e.performance.setResourceTimingBufferSize)e.performance.setResourceTimingBufferSize();!function(){if(BOOMR=e.BOOMR||{},BOOMR.plugins=BOOMR.plugins||{},!BOOMR.plugins.AK){var n=""=="true"?1:0,t="",a="fx4wpzyxa6xciykjx36q-f-ffb1bc24e-clientnsv4-s.akamaihd.net",i="false"=="true"?2:1,o={"ak.v":"32","ak.cp":"931990","ak.ai":parseInt("449863",10),"ak.ol":"0","ak.cr":94,"ak.ipv":4,"ak.proto":"http/1.1","ak.rid":"175c64ac","ak.r":20734,"ak.a2":n,"ak.m":"b","ak.n":"essl","ak.bpcip":"45.249.103.0","ak.cport":52406,"ak.gh":"104.84.150.30","ak.quicv":"","ak.tlsv":"tls1.2","ak.0rtt":"","ak.csrc":"-","ak.acc":"bbr","ak.t":"1632222973","ak.ak":"hOBiQwZUYzCg5VSAfCLimQ==WbmwJljNK94QTUFyyiLTaQ+DqYjvc2hz39MiW6YJceU1IVz/lbO1berlMIaciXiwo+/T3ifItFCd+kKXHmHqXYe6+hdZeVAH490beCtjH2l8S6RVXheNpKpwLu0TOq663f0+BD0ZqFsCNY5z2iDU1FagOiqcz/jGTKGQ4mei+bm8ImxVwjmCw81gSHGkGyvMYEbBQND/KKtT8EmSkN9EtNQT2WI4+4O5cWvBeo8xLrqsG82T0pUfHX9Xuo2Ny6AXYoqOT1hgg3z+2rvWyvuqvXefGF1/YoAJ8hsbR9i8ThZEyRDz3c8rMqZfcacSNKhf4ARw6keUqdgjOYE/DJYm20jZdZiegOgw7v/NV3VRBKzow/90iuYbZ496t360uAgL4G8Hdjh1WgYrBUkkq0H6zZ4OeC9Xr7kIUX+o1XRJVrY=","ak.pv":"220","ak.dpoabenc":"","ak.tf":i};if(""!==t)o["ak.ruds"]=t;var r={i:!1,av:function(n){var t="http.initiator";if(n&&(!n[t]||"spa_hard"===n[t]))o["ak.feo"]=void 0!==e.aFeoApplied?1:0,BOOMR.addVar(o)},rv:function(){var e=["ak.bpcip","ak.cport","ak.cr","ak.csrc","ak.gh","ak.ipv","ak.m","ak.n","ak.ol","ak.proto","ak.quicv","ak.tlsv","ak.0rtt","ak.r","ak.acc","ak.t","ak.tf"];BOOMR.removeVar(e)}};BOOMR.plugins.AK={akVars:o,akDNSPreFetchDomain:a,init:function(){if(!r.i){var e=BOOMR.subscribe;e("before_beacon",r.av,null,null),e("onbeacon",r.rv,null,null),r.i=!0}return this},is_complete:function(){return!0}}}}()}(window);</script></head>

<body>
  <!-- Google Tag Manager (noscript) -->
  <noscript>
    <img height="1" width="1" src="https://www.facebook.com/tr?id=1523660554311788&ev=PageView&noscript=1" />
  </noscript>
  <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N52Q36S" height="0"
      width="0" style="display:none;visibility:hidden"></iframe></noscript>
  <!-- End Google Tag Manager (noscript) -->
  <div id="app" style="min-height: 100vh;"></div>
  <div class="footer-more-wrapper">
    <div class="footer-content container responsive-layout" id="footer">
      <h5>Why Buy? – Car Subscription is Here</h5>
      <p>Owning a car is a huge commitment, one that can take up all the effort and resources. With modern lifestyles
        saddling us with so many other responsibilities, it may be time to rethink the whole process.</p>
      <h5>Buying a Car – A Financial Strain </h5>
      <p>The down-payment of a car is the first part of the obstacle. You would be expected to shell out a rather big
        sum of money, the kind that you would have to stretch to accumulate. Other payments like road taxes and
        insurance also add to the list of expenditures. It can result in compromises in your lifestyle. Even worse, in
        times of emergency you might not have access to funds because you have spent it all on the down payment. That
        same amount could have got you other things. You could have even invested it somewhere else.</p>
      <h5>Long-term Liabilities</h5>
      <p>Then of course, the monthly EMIs add a long-term liability to your personal finances. This goes on for years
        and can be a stumbling block for your other plans. While you are paying EMIs on the premium cost of your car,
        the vehicle itself is ageing and has cost more money in its upkeep. You are not only paying big monthly sums for
        the car, but as time progresses, you will be juggling these with costs on repairs and maintenance. Unless you
        are the car loan company, it does not sound like a pleasant deal.</p>
      <h5>Car Subscription</h5>
      <p>This is the reason why car subscription is becoming a smart and viable option for a whole new generation of
        commuters. Zoomcar's latest service – the
        Zoomcar Subscription, a Car program is addressing the needs of travellers who
        yearn the privileges of car ownership. Why buy a car and be saddled with car loans and car EMIs when you can
        just pay for a vehicle for using it.</p>
      <h5>Zoomcar Subscription – Difference from Car Leasing</h5>
      <p>Traditional car leasing companies do not offer the same perks as Zoomcar Subscription.
        Zoomcar is tech-driven so there is not much human correspondence required,
        saving you a lot of time. You get to choose from a large collection of cars – hatchbacks, sedans, SUVS. The
        subscription can be facilitated with ease over a dedicated app and you can book a car from
        1 month
        to 3 months. This is especially useful for people who move a lot and
        are not keen on having too many permanent assets.</p>
      <p>Another hallmark of the Zoomcar Subscription is that you can rent
        your car out when you do not need it. This way, you can further reduce your car subscription costs.</p>
      <div class="read-more" onclick="expandFooter()">
        Read More
      </div>
    </div>
  </div>
<script type="text/javascript" src="https://www.zoomcar.com/zap/subscribe/build/vendor-166a37cdf7d2b3365bc8.bundle.js"></script><script type="text/javascript" src="https://www.zoomcar.com/zap/subscribe/build/app-166a37cdf7d2b3365bc8.bundle.js"></script></body>

<script>
  function expandFooter() {
    document.querySelector('.footer-content').classList.add('expanded');
    document.querySelector('.read-more').style.display = 'none';
  }
</script>
<script type="text/javascript" src=""></script>

</html>